'''
Tests for PyNCrypt
'''