'''
SSL Tests for PyNCrypt
'''